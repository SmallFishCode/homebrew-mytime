const now = new Date().toLocaleString();
console.log(`云舟提醒您，现在是： ${now}`);